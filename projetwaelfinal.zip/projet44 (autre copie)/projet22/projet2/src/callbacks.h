#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button5wg_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button6wg_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_wael_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonmodifwg_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2mowg_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonrechwg_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonrecherchwg_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonretourrechwg_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_capteurtemps_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_capteurhumdwg_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_capteurs_alarmats_wg_clicked (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_capteur_wg_clicked    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_wg_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_wg_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_wg_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_wg_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
